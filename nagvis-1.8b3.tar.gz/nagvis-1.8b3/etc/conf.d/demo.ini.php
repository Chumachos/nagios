; <?php return 1; ?>
; the line above is to prevent
; viewing this file from web.
; DON'T REMOVE IT!

; This file defines a backend instance of the Test backend
; which is used by some demo maps. This can be removed when
; you are not interested in the demo maps.

[backend_demo]
backendtype=Test
